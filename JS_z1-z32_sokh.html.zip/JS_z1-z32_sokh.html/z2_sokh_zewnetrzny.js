document.write("ostatnia modyfikacja strony".bold().fontsize(5).fontcolor("#00FF00")+"<br>");
document.write(document.lastModified);